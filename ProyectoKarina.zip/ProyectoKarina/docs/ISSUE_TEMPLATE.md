<!-- This tracker is only for issues specific to this example app. For example, if you have trouble
     building an unmodified copy of this app, or you have issues with the console functionality, you
     can report that here.

     For anything else, please go to https://github.com/chaquo/chaquopy/issues -->

