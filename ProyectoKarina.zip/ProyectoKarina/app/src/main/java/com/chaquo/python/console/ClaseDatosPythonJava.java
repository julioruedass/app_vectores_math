package com.chaquo.python.console;

public class ClaseDatosPythonJava {
    public static float lado1;
    public static float lado2;
    public static float area;



    public static int componentes;

    public static String v1[] = new String [4];
    public static String v2[] = new String [4];
    public static String v3[] = new String [4];
    public static String v4[] = new String [4];
    public static String A1[][] = new String [4][4];

    public static String latexMatriz = new String();

    public static int procedimiento = 0;

    /*public static float v1_dato1;
    public static float v1_dato2;
    public static float v1_dato3;
    public static float v1_dato4;
    public static float v2_dato1;
    public static float v2_dato2;
    public static float v2_dato3;
    public static float v2_dato4;
    public static float v3_dato1;
    public static float v3_dato2;
    public static float v3_dato3;
    public static float v3_dato4;
    public static float v4_dato1;
    public static float v4_dato2;
    public static float v4_dato3;
    public static float v4_dato4;*/
    public static String u1[][] = new String[5][5];



    public ClaseDatosPythonJava() {
        v1 = new String[4];
    }

    public static float getLado1() {
        return lado1;
    }

    public static void setLado1(float lado1) {
        ClaseDatosPythonJava.lado1 = lado1;
    }

    public static float getLado2() {
        return lado2;
    }

    public static void setLado2(float lado2) {
        ClaseDatosPythonJava.lado2 = lado2;
    }

    public static float getArea() {
        return area;
    }

    public static void setArea(float area) {
        ClaseDatosPythonJava.area = area;
    }

    /*public static float getv1_dato1() {
        return v1_dato1;
    }

    public static void setv1_dato1(float v1_dato1) {
        ClaseDatosPythonJava.v1_dato1 = v1_dato1;
    }

    public static float getv1_dato2() {
        return v1_dato2;
    }

    public static void setv1_dato2(float v1_dato2) {
        ClaseDatosPythonJava.v1_dato2 = v1_dato2;
    }

    public static float getv1_dato3() {
        return v1_dato3;
    }

    public static void setv1_dato3(float v1_dato3) {
        ClaseDatosPythonJava.v1_dato3 = v1_dato3;
    }

    public static float getv1_dato4() {
        return v1_dato4;
    }

    public static void setv1_dato4(float v1_dato4) {
        ClaseDatosPythonJava.v1_dato4 = v1_dato4;
    }

    public static float getv2_dato1() {
        return v2_dato1;
    }

    public static void setv2_dato1(float v2_dato1) {
        ClaseDatosPythonJava.v2_dato1 = v2_dato1;
    }

    public static float getv2_dato2() {
        return v2_dato2;
    }

    public static void setv2_dato2(float v2_dato2) {
        ClaseDatosPythonJava.v2_dato2 = v2_dato2;
    }

    public static float getv2_dato3() {
        return v2_dato3;
    }

    public static void setv2_dato3(float v2_dato3) {
        ClaseDatosPythonJava.v2_dato3 = v2_dato3;
    }

    public static float getv2_dato4() {
        return v2_dato4;
    }

    public static void setv2_dato4(float v2_dato4) {
        ClaseDatosPythonJava.v2_dato4 = v2_dato4;
    }

    public static float getv3_dato1() {
        return v3_dato1;
    }

    public static void setv3_dato1(float v3_dato1) {
        ClaseDatosPythonJava.v3_dato1 = v3_dato1;
    }

    public static float getv3_dato2() {
        return v3_dato2;
    }

    public static void setv3_dato2(float v3_dato2) {
        ClaseDatosPythonJava.v3_dato2 = v3_dato2;
    }

    public static float getv3_dato3() {
        return v3_dato3;
    }

    public static void setv3_dato3(float v3_dato3) {
        ClaseDatosPythonJava.v3_dato3 = v3_dato3;
    }

    public static float getv3_dato4() {
        return v3_dato4;
    }

    public static void setv3_dato4(float v3_dato4) {
        ClaseDatosPythonJava.v3_dato4 = v3_dato4;
    }

    public static float getv4_dato1() {
        return v4_dato1;
    }

    public static void setv4_dato1(float v4_dato1) {
        ClaseDatosPythonJava.v4_dato1 = v4_dato1;
    }

    public static float getv4_dato2() {
        return v4_dato2;
    }

    public static void setv4_dato2(float v4_dato2) {
        ClaseDatosPythonJava.v4_dato2 = v4_dato2;
    }

    public static float getv4_dato3() {
        return v4_dato3;
    }

    public static void setv4_dato3(float v4_dato3) {
        ClaseDatosPythonJava.v4_dato3 = v4_dato3;
    }

    public static float getv4_dato4() {
        return v4_dato4;
    }

    public static void setv4_dato4(float v4_dato4) {
        ClaseDatosPythonJava.v4_dato4 = v4_dato4;
    } */

    public static String[][] getresultado() {
        return u1;
    }

    public static void setresultado(String[][] u1) {
        ClaseDatosPythonJava.u1 = u1;
    }
    public static int getComponentes() {
        return componentes;
    }

    public static void setComponentes(int componentes) {
        ClaseDatosPythonJava.componentes = componentes;
    }

}

