package com.chaquo.python.console;

//import android.support.v7.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.agog.mathdisplay.MTMathView;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class BaseOrtonormal extends AppCompatActivity {

    EditText textNumber_componentes;
    EditText editText_v1_dato1;
    EditText editText_v1_dato2;
    EditText editText_v1_dato3;
    EditText editText_v1_dato4;
    EditText editText_v2_dato1;
    EditText editText_v2_dato2;
    EditText editText_v2_dato3;
    EditText editText_v2_dato4;
    EditText editText_v3_dato1;
    EditText editText_v3_dato2;
    EditText editText_v3_dato3;
    EditText editText_v3_dato4;
    EditText editText_v4_dato1;
    EditText editText_v4_dato2;
    EditText editText_v4_dato3;
    EditText editText_v4_dato4;
    TextView textview_resultado;
    TextView textview_procedimiento;
    Button button_resultado;
    Button button_procedimiento;

    MTMathView mathView_formula1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_ortonormal);

        textNumber_componentes = findViewById(R.id.editTextNumber);
        editText_v1_dato1 = findViewById(R.id.editText_v1_dato1);
        editText_v1_dato2 = findViewById(R.id.editText_v1_dato2);
        editText_v1_dato3 = findViewById(R.id.editText_v1_dato3);
        editText_v1_dato4 = findViewById(R.id.editText_v1_dato4);
        editText_v2_dato1 = findViewById(R.id.editText_v2_dato1);
        editText_v2_dato2 = findViewById(R.id.editTextT_v2_dato2);
        editText_v2_dato3 = findViewById(R.id.editText_v2_dato3);
        editText_v2_dato4 = findViewById(R.id.editText_v2_dato4);
        editText_v3_dato1 = findViewById(R.id.editText_v3_dato1);
        editText_v3_dato2 = findViewById(R.id.editText_v3_dato2);
        editText_v3_dato3 = findViewById(R.id.editText_v3_dato3);
        editText_v3_dato4 = findViewById(R.id.editText_v3_dato4);
        editText_v4_dato1 = findViewById(R.id.editText_v4_dato1);
        editText_v4_dato2 = findViewById(R.id.editText_v4_dato2);
        editText_v4_dato3 = findViewById(R.id.editText_v4_dato3);
        editText_v4_dato4 = findViewById(R.id.editText_v4_dato4);
        button_resultado = findViewById(R.id.button_resultadoOrtonormal);
        textview_resultado = findViewById(R.id.textView9);
        button_procedimiento = findViewById(R.id.button_procedimientoOrtonormal);
        textview_procedimiento = findViewById(R.id.textView10);

        mathView_formula1 = findViewById(R.id.mathviewFormula1);
        mathView_formula1.setFontSize(50);
        mathView_formula1.setScrollContainer(true);


        button_procedimiento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ClaseDatosPythonJava.procedimiento = 1;
            }
        });

        // Revisar si Python está iniciado
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        // Obtener una instancia Python, punto de inicio para enlace Java-Python
        final Python py = Python.getInstance();

        button_resultado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //encontrar una base ortonormal resultado
                // es la clase claseDatosPythonJava

                //ClaseDatosPythonJava.A1 = new String[4][4];
                //ClaseDatosPythonJava.v1 = new String[4];
                //ClaseDatosPythonJava.v2 = new String[4];
                //ClaseDatosPythonJava.v3 = new String[4];
                //ClaseDatosPythonJava.v4 = new String[4];


                ClaseDatosPythonJava.componentes = Integer.parseInt(textNumber_componentes.getText().toString());
                ClaseDatosPythonJava.v1[0] = (editText_v1_dato1.getText().toString());
                ClaseDatosPythonJava.v1[1] = (editText_v1_dato2.getText().toString());
                ClaseDatosPythonJava.v1[2] = (editText_v1_dato3.getText().toString());
                ClaseDatosPythonJava.v1[3] = (editText_v1_dato4.getText().toString());
                ClaseDatosPythonJava.v2[0] = (editText_v2_dato1.getText().toString());
                ClaseDatosPythonJava.v2[1] = (editText_v2_dato2.getText().toString());
                ClaseDatosPythonJava.v2[2] = (editText_v2_dato3.getText().toString());
                ClaseDatosPythonJava.v2[3] = (editText_v2_dato4.getText().toString());
                ClaseDatosPythonJava.v3[0] = (editText_v3_dato1.getText().toString());
                ClaseDatosPythonJava.v3[1] = (editText_v3_dato2.getText().toString());
                ClaseDatosPythonJava.v3[2] = (editText_v3_dato3.getText().toString());
                ClaseDatosPythonJava.v3[3] = (editText_v3_dato4.getText().toString());
                ClaseDatosPythonJava.v4[0] = (editText_v4_dato1.getText().toString());
                ClaseDatosPythonJava.v4[1] = (editText_v4_dato2.getText().toString());
                ClaseDatosPythonJava.v4[2] = (editText_v4_dato3.getText().toString());
                ClaseDatosPythonJava.v4[3] = (editText_v4_dato4.getText().toString());



                // Crear objeto Python para vincular con programa Python
                PyObject pyo = py.getModule("main");
                // Llamar función Python y especificar parámetros si existen
                Object obj = pyo.callAttr("main");
                // Recuperar resultado de función Python

                /*
                String[][] resultado = ClaseDatosPythonJava.A1;

                String cadena = "";
                for (int i = 0; i< resultado[i].length; i++){
                    for (int j = 0; j< 4; j++){
                        cadena = cadena+ resultado[i][j];

                    }
                    cadena = cadena+"\n";
                }
                String[][] u1 = ClaseDatosPythonJava.u1;

                 */
                // Mostrar resultado en GUI del usuario
                //textview_resultado.setText(cadena);
                textview_resultado.setText(ClaseDatosPythonJava.latexMatriz);

                mathView_formula1.setLatex(ClaseDatosPythonJava.latexMatriz);


            }
        });

    }

}