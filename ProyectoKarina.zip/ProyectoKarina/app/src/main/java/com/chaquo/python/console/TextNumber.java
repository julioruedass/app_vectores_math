package com.chaquo.python.console;

public class TextNumber {
}
