package com.chaquo.python.console;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;


public class ActividadRectangulo extends AppCompatActivity {

    TextView textview_resultado;
    EditText editText_lado1;
    EditText editText_lado2;
    Button button_calculararea;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_rectangulo);

        button_calculararea = findViewById(R.id.button_arearectangulo);
        editText_lado1 = findViewById(R.id.editTextNumberDecimal_lado1);
        editText_lado2 = findViewById(R.id.editTextNumberDecimal_lado2);
        textview_resultado = findViewById(R.id.textView_resultadoarea);

        // Revisar si Python está iniciado
        if(!Python.isStarted()){
            Python.start(new AndroidPlatform(this));
        }
        // Obtener una instancia Python, punto de inicio para enlace Java-Python
        final Python py = Python.getInstance();




        button_calculararea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //recuperar lado1 y lado2 y guardar en la clase que sirvirá de comunicación entre java y python
                // es la clase claseDatosPythonJava

                ClaseDatosPythonJava.lado1 = Float.parseFloat(editText_lado1.getText().toString());
                ClaseDatosPythonJava.lado2 = Float.parseFloat(editText_lado2.getText().toString());

                // Crear objeto Python para vincular con programa Python
                PyObject pyo = py.getModule("rectanguloarea");
                // Llamar función Python y especificar parámetros si existen
                Object obj = pyo.callAttr("rectanguloarea");
                // Recuperar resultado de función Python

                float area = ClaseDatosPythonJava.area;
                // Mostrar resultado en GUI del usuario
                textview_resultado.setText("Resultado: " + area);


            }
        });

    }
}
