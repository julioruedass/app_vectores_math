from sympy import sqrt, Matrix, init_printing, pprint, Identity, shape, eye

def leerVector():
    vstr = input("Ingrese su vector separado por comas\n")
    v = Matrix(vstr.split(","))
    return v


def leerBase(dim):
    A = []
    for i in range(dim):
        v1str = input(f"Ingrese el renglón {i} de numeros separados por comas\n")
        A.append(v1str.split(","))
    return Matrix(A)


def cambioDeBase(v,B1,B2):
    vp = B1 * v
    print("Se multiplicó el vector por su base para hacerlo canonico")
    pprint(vp)
    vp = inversa(B2) * vp
    print("Se multiplicó el vector canonico con la matriz de transición")
    pprint(vp)



def bases(dim):
    flag = True
    while(flag):
        baseStr = input("En que base esta tu vector: Canonica(C), Base1(B1) o Base2(B2)?\n")
        if baseStr == "C":
            flag = False
            print("Favor de ingresar Base2")
            B2 = leerBase(dim)
            B1 = Identity(dim)
            return B1,B2
        elif baseStr == "B1":
            flag = False
            print("Favor de ingresar Base1")
            B1 = leerBase(dim)
            print("Favor de ingresar Base2")
            B2 = leerBase(dim)
            return B1,B2
        elif baseStr == "B2":
            flag = False
            print("Favor de ingresar Base1")
            B1 = leerBase(dim)
            print("Favor de ingresar Base2")
            B2 = leerBase(dim)
            return B2,B1




def inversa(Matriz):
    A = Matriz.copy()
    Shape = A.shape
    Res = eye(Shape[0])
    try:
        A.inv()
    except:
        return None
    print("Entrada")
    pprint(A.row_join(Res))
    for j in range(Shape[0]):
        if A[j, j] == 0:
            for i in range(Shape[0]):
                if A[i, j] != 0:
                    print(f"swap {j},{i}")
                    A.row_swap(j, i)
                    Res.row_swap(j, i)
                    pprint(A.row_join(Res))
        print(f"Hacer 1 pivote en A{j} := A{j} * 1/A[j,j]")
        A[j, :] = A[j, :] * 1 / A[j, j]
        Res[j, :] = Res[j, :] * 1 / A[j, j]
        pprint(A.row_join(Res))
        for i in range(j + 1, Shape[0]):
            print(f"Hacer 0 fila A[{i}] = A[{i}] - (A[{j}] * A[{i},{j}])")
            A[i, :] = A[i, :] - (A[j, :] * A[i, j])
            Res[i, :] = Res[i, :] - (Res[j, :] * A[i, j])
            pprint(A.row_join(Res))
    for j in range(Shape[0] - 1, -1, -1):
        for i in range(j - 1, -1, -1):
            print(f"Hacer 0 fila A[{i}] = A[{i}] - (A[{j}] * A[{i},{j}])")
            A[i, :] = A[i, :] - (A[j, :] * A[i, j])
            Res[i, :] = Res[i, :] - (Res[j, :] * A[i, j])
            pprint(A.row_join(Res))
    return Res

