from com.chaquo.python.console import ClaseDatosPythonJava as Datos
from sympy import sqrt, Matrix, init_printing, pprint
from sympy import latex

init_printing()

def normalizacion(v,verbose=0):
  if verbose:
    print("Normalizamos el vector")
    pprint(v)
    print("u = 1/|v| * v")
  count=0
  for i in v:
    count = i**2 + count
  raiz = 1/sqrt(count) * v
  if verbose:
    print("Obtenemos")
    pprint(raiz)
  return raiz

def gramSchmidt(L,verbose=0):
  u =[]
  if verbose:
    print("Vectores de entrada")
    pprint(L)
  for v in L:
    vp = v
    for u_temp in u:
      vp = vp - v.dot(u_temp) * u_temp
      pc = v.dot(u_temp)
      if verbose:
        print("Resultado de producto punto")
        pprint(pc)
        print("Ortogonalizamos v")
        pprint(vp)
        print("Respecto a u")
        pprint(u_temp)
      if verbose:
        print("Obtenemos")
        pprint(vp)
    u_temp = normalizacion(vp,verbose)
    u.append(u_temp)
  print(f"Base ortonormal en R{v.shape[0]}")
  ##u=Matrix(u)
  pprint(u)
  #Datos.u1 = u
  Datos.latexMatriz = array_to_LaTeX(u)

  return u

def array_to_LaTeX(arr):
 return latex(arr)



def leerMatriz():
  dimstr = Datos.componentes
  x = Datos.procedimiento
  if x == 1:
      verbose = 1
  else:
      verbose = 0
  A = []
  for i in range(int(dimstr)):
    if i == 0:
      #v1str = np.array(Datos.v1).tolist()
      A.append(Matrix(Datos.v1))
    if i == 1:
      #v1str = np.array(Datos.v2).tolist()
      A.append(Matrix(Datos.v2))
    if i == 2:
      #v1str = np.array(Datos.v3).tolist()
      A.append(Matrix(Datos.v3))
    if i == 3:
      #v1str = np.array(Datos.v4).tolist()
      A.append(Matrix(Datos.v4))

  pprint("Matriz A original")
  pprint(A)
  return A,verbose